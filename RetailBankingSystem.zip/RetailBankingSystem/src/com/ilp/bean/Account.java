package com.ilp.bean;

public class Account {
	private long AccountID ;
	private long CustID; 
	private String AccountType; 
	private double Balance; 
	private String Start_Date;  
	private String End_Date;  
	private String Status;
	public Account(long accountID, long custID, String accountType,
			double balance, String start_Date, String end_Date, String status) {
		super();
		AccountID = accountID;
		CustID = custID;
		AccountType = accountType;
		Balance = balance;
		Start_Date = start_Date;
		End_Date=end_Date;
		Status = status;
	}
	public long getAccountID() {
		return AccountID;
	}
	public void setAccountID(long accountID) {
		AccountID = accountID;
	}
	public long getCustID() {
		return CustID;
	}
	public void setCustID(long custID) {
		CustID = custID;
	}
	public String getAccountType() {
		return AccountType;
	}
	public void setAccountType(String accountType) {
		AccountType = accountType;
	}
	public double getBalance() {
		return Balance;
	}
	public void setBalance(double balance) {
		Balance = balance;
	}
	public String getStart_Date() {
		return Start_Date;
	}
	public void setStart_Date(String start_Date) {
		Start_Date = start_Date;
	}
	public String getStatus() {
		return Status;
	}
	public void setStatus(String status) {
		Status = status;
	}
	public String getEnd_Date() {
		return End_Date;
	}
	public void setEnd_Date(String end_Date) {
		End_Date = end_Date;
	} 
	

}
