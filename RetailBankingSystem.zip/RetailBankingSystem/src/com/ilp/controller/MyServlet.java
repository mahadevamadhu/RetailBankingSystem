package com.ilp.controller;

import java.io.IOException;
import java.sql.SQLException;
import java.util.ArrayList;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.ilp.bean.Account;
import com.ilp.bean.Customer;
import com.ilp.service.AccountsNotFoundException;
import com.ilp.service.CustomerAlreadyDeletedException;
import com.ilp.service.CustomerInvalidException;
import com.ilp.service.CustomerNotFoundException;
import com.ilp.service.InactiveAccountException;
import com.ilp.service.InsufficientbalanceException;
import com.ilp.service.InvalidCustidException;
import com.ilp.service.InvalidSsnidException;
import com.ilp.service.Service;

/**
 * Servlet implementation class MyServlet
 */
public class MyServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public MyServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		//response.getWriter().append("Served at: ").append(request.getContextPath());
		doPost(request,response);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
	//creating a session object here..
		HttpSession mySession = request.getSession();
		Service s=new Service();
		
		String action=request.getParameter("action");
		System.out.println(action);
		String username=request.getParameter("username");
		String password=request.getParameter("password");
		String department="";
		
		//For Login
		
		if(action.equals("index"))
		{
				
					department = s.login(username, password);
					System.out.println(department);
				
			
					
				if(department.equals("executive"))
				{
					request.setAttribute("username", username);
					request.setAttribute("role", department);
					RequestDispatcher rd=request.getRequestDispatcher("ExecutivePage.jsp");
					rd.forward(request, response);
				}
				else if(department.equals("cashier"))
				{
					request.setAttribute("username", username);
					request.setAttribute("role", department);
					RequestDispatcher rd=request.getRequestDispatcher("WelcomeCashier.jsp");
					rd.forward(request, response);
				}
				else if(department.equals("fail"))
				{
					
					RequestDispatcher rd=request.getRequestDispatcher("failure.jsp");
					rd.forward(request, response);
				}
		}
		
		//--------------------------------------------------------------------------------------
		
		// EXECUTIVE OPERATIONS
		
		//For Add customer
		
		else if(action.equals("AddCustomer"))
		{
			RequestDispatcher rc=request.getRequestDispatcher("AddCustomer.jsp");
			rc.forward(request, response);
		}
		else if(action.equals("addcustomer"))
		{
			long ssnid = Long.parseLong(request.getParameter("ssnid"));
			String name = request.getParameter("name");
			int age = Integer.parseInt(request.getParameter("age"));
			String addline1 = request.getParameter("addline1");
			String addline2 = request.getParameter("addline2");
			String city = request.getParameter("city");
			String state = request.getParameter("state");
			
			Customer c=new Customer(ssnid,name,age,addline1,addline2,city,state);
		
			try {
				boolean flag=s.register(c);
				request.setAttribute("flag", flag);
				RequestDispatcher rd=request.getRequestDispatcher("CustomerAddedSucessfully.jsp");
				rd.forward(request, response);
			} 
			catch (CustomerInvalidException e) 
			{
				RequestDispatcher rd=request.getRequestDispatcher("failure.jsp");
				rd.forward(request, response);
			}

			
		}
		
		//-----------------------------------------------------------------------------------------
		
		//For Update customer
		
		else if(action.equals("UpdateCustomer"))
		{
			
			RequestDispatcher rd=request.getRequestDispatcher("Update1.jsp");
			rd.forward(request, response);
		}
		
		else if(action.equals("fetch"))
		{
				Customer c=new Customer();
				System.out.println(action);
				String id=request.getParameter("id");
				if(id.equals("ssnid"))
				{
					long SSNId=Long.parseLong(request.getParameter("selectedid"));
					
					try {
						c=s.fetchServicessnid(SSNId);
						request.setAttribute("Cust", c);
						RequestDispatcher rc=request.getRequestDispatcher("Update2.jsp");
						rc.forward(request, response);
					}
					catch (CustomerNotFoundException e) 
					{
						RequestDispatcher rd=request.getRequestDispatcher("CustomerNotFound.jsp");
						rd.forward(request, response);
					}
				}
				
				else if(id.equals("custid"))
				{
					
					long custid=Long.parseLong(request.getParameter("selectedid"));
					
					try {
						c=s.fetchServicecustid(custid);
						request.setAttribute("Cust", c);
						RequestDispatcher rc=request.getRequestDispatcher("Update2.jsp");
						rc.forward(request, response);
					}
					catch (CustomerNotFoundException e) 
					{
						RequestDispatcher rd=request.getRequestDispatcher("CustomerNotFound.jsp");
						rd.forward(request, response);
					}
				}
				
		}
	//-----------------------------------------------------------------------------------------------	
		else if(action.equals("updatecust"))
		{
			System.out.println("abc");
			long ssnid = Long.parseLong(request.getParameter("ssnidup"));
			System.out.println(ssnid);
			long custid = Long.parseLong(request.getParameter("custidup"));
			String name = request.getParameter("nameup");
			int age = Integer.parseInt(request.getParameter("ageup"));
			String addline1 = request.getParameter("address1up");
			String addline2 = request.getParameter("address2up");
			String city = request.getParameter("cityup");
			String state = request.getParameter("stateup");
			
			Customer c= new Customer(ssnid, custid, name, age, addline1, addline2, city, state);
			boolean f=s.UpdateCustom(c);
			if(f==true)
			{
				RequestDispatcher rd=request.getRequestDispatcher("SucessUpdate.jsp");
				rd.forward(request, response);
			}
			else
			{
				RequestDispatcher rd=request.getRequestDispatcher("UnSucessUpdate.jsp");
				rd.forward(request, response);
			}
			
		}
		
		//----------------------------------------------------------------------------------------------
		
		//For Delete Customer
		
		else if(action.equals("AddAccount"))
		{
			RequestDispatcher rd=request.getRequestDispatcher("AddAccount.jsp");
			rd.forward(request, response);
		}
		else if(action.equals("addacc"))
		{
			long custid=Long.parseLong(request.getParameter("custid"));
			String accType=request.getParameter("type");
			double bal=Double.parseDouble(request.getParameter("amount"));
			boolean flag=s.AddAccount(custid, accType, bal);
			if(flag==true)
			{
				RequestDispatcher rd=request.getRequestDispatcher("AccountAddedSucess.jsp");
				rd.forward(request, response);
			}
			else
			{
				RequestDispatcher rd=request.getRequestDispatcher("AccountAddedFailed.jsp");
				rd.forward(request, response);
			}
		}
		
		//--------------------------------------------------------------------------------
		else if(action.equals("DeleteAccount"))
		{
			RequestDispatcher rd=request.getRequestDispatcher("DeleteCustomer.jsp");
			rd.forward(request,response);
		}
		else if(action.equals("DeleteCustomer"))
		{
			RequestDispatcher rd=request.getRequestDispatcher("DeleteAccount.jsp");
			rd.forward(request,response);
		}
		else if(action.equals("delete"))
		{
			long custid = Long.parseLong(request.getParameter("custid"));
			boolean check=false;
			try {
				check = s.checkcust(custid);
			} catch (CustomerAlreadyDeletedException e) {
				// TODO Auto-generated catch block
				RequestDispatcher rd=request.getRequestDispatcher("CustomerAlreadyDeleted.jsp");
				rd.forward(request, response);
			}
				
			if(check==true)
			{
		
				request.setAttribute("custid", custid);
				RequestDispatcher rd=request.getRequestDispatcher("DeleteConfirmation.jsp");
				rd.forward(request, response);
			}
		}
		
		else if(action.equals("DELETE"))
		{
			long custid=Long.parseLong(request.getParameter("custid"));
			System.out.println(custid);
			boolean delete;

			delete = s.deletecust(custid);
			
			System.out.println(delete);
			if(delete==true)
			{
				RequestDispatcher rd=request.getRequestDispatcher("DeleteSuccessfull.jsp");
				rd.forward(request, response);
			}
			else
			{
				RequestDispatcher rd=request.getRequestDispatcher("DeleteFailed.jsp");
				rd.forward(request, response);
				
			}
		}
	
		
		
	//---------------------------------------------------------------------------------------
	
		else if(action.equals("delAccount"))
		{
			boolean f=false;
			boolean f2=false;
			String id=request.getParameter("id");
			if(id.equals("ssnid"))
			{
				long ssnid=Long.parseLong(request.getParameter("selectedid"));
					try 
					{
						f=s.checkCredentialSSnid(ssnid);
						f2=s.deleteAccountBySsnid(ssnid);
						if(f2==true)
						{
							RequestDispatcher rd=request.getRequestDispatcher("AccountDeletedSuccessfull.jsp");
							rd.forward(request, response);
						}
						else
						{
							RequestDispatcher rc=request.getRequestDispatcher("AccountDeletionFailed.jsp");
							rc.forward(request, response);
						}
						
					}
					catch (InvalidSsnidException e) {
						// TODO Auto-generated catch block
						System.out.println("def");
						RequestDispatcher rd=request.getRequestDispatcher("InvalidCredential.jsp");
						rd.forward(request, response);
					}
				
			}
			else if(id.equals("custid"))
			{
				long custid=Long.parseLong(request.getParameter("selectedid"));
				try {
					
					f=s.checkCredentialCustid(custid);
					f2=s.deleteAccountByCustid(custid);
					if(f2==true)
					{
						RequestDispatcher rd=request.getRequestDispatcher("AccountDeletedSuccessfull.jsp");
						rd.forward(request, response);
					}
					else
					{
						RequestDispatcher rc=request.getRequestDispatcher("AccountDeletionFailed.jsp");
						rc.forward(request, response);
					}
					
				} catch (InvalidCustidException e) {
					System.out.println("xyz");
					// TODO Auto-generated catch block
					RequestDispatcher rd=request.getRequestDispatcher("InvalidCredential.jsp");
					rd.forward(request, response);
				}
			}
			
		}
		//Cashier Operations Starts from here...
		//--------------------------------------------------------------------------------------
		else if(action.equals("viewAccount"))
			
		{
			
			String id=request.getParameter("id");
			if(id.equals("ssnid"))
			{
				long ssnid=Long.parseLong(request.getParameter("selectedid"));
				
				ArrayList<Account> alist=new ArrayList<Account>();
				try {
					alist=s.getAccountListBySsnid(ssnid);
					for(Account a:alist)
					{
						System.out.println(a.getAccountID());
					}
					System.out.println();
					request.setAttribute("slist", alist);
					RequestDispatcher rd=request.getRequestDispatcher("DisplayAccountsBySsnid.jsp");
					rd.forward(request, response);
				} catch (AccountsNotFoundException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				
				
			}
			else if(id.equals("custid"))
			{
				System.out.println("abc");
				long custid=Long.parseLong(request.getParameter("selectedid"));
				
				ArrayList<Account> alist=new ArrayList<Account>();
				try {
					alist=s.getAccountListByCustid(custid);
					for(Account a:alist)
					{
						System.out.println(a.getAccountID());
					}
					request.setAttribute("clist", alist);
					RequestDispatcher rd=request.getRequestDispatcher("DisplayAccountsByCustid.jsp");
					rd.forward(request, response);
				} catch (AccountsNotFoundException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				
				
			}
			
			else if(id.equals("accid"))
			{
				long accid=Long.parseLong(request.getParameter("selectedid"));
				Account account=s.getAccount(accid);
				
				request.setAttribute("acc", account);
				RequestDispatcher rd=request.getRequestDispatcher("DisplayAccountDetails.jsp");
				rd.forward(request, response);
				account=s.getAccount(accid);
			}
		
		}
		
	//-------------------------------------------------------------------------------------------
	
		else if(action.equals("displayAcc"))
		{
			int aid=Integer.parseInt(request.getParameter("ssnidacc"));
			Account ac=s.getAccount(aid);
			request.getSession().setAttribute("accountDetails", ac);
			request.setAttribute("acc", ac);
			RequestDispatcher rd=request.getRequestDispatcher("DisplayAccountDetails.jsp");
			rd.forward(request, response);
			System.out.println(aid);
			
		}
		else if(action.equals("transfReq"))
		{
			long accountid=Long.parseLong(request.getParameter("SourceAcc"));
			long targetid=Long.parseLong(request.getParameter("TargetAcc"));
			double transfAmt = Double.parseDouble(request.getParameter("TransferAmt"));
			
			double beforesouce=s.getBalancesource(accountid);
			System.out.println("the sourceBalance "+beforesouce);
			request.setAttribute("beforesouce", beforesouce);
			request.setAttribute("accountid", accountid);
			request.setAttribute("targetid", targetid);
			double beforetarget=s.getBalancetarget(targetid);
			System.out.println("the beforetarget "+beforetarget);
			request.setAttribute("beforetarget", beforetarget);
			
			try 
			{
				s.updatebalance(accountid, targetid, transfAmt);
				double aftersource=s.getBalancesource(accountid);
				System.out.println("the aftersource "+aftersource);
				request.setAttribute("aftersource", aftersource);
				double aftertarget=s.getBalancetarget(targetid);
				System.out.println("the aftersource "+aftertarget);
				request.setAttribute("aftertarget", aftertarget);
				
				RequestDispatcher rd=request.getRequestDispatcher("TransferSuccess.jsp");
				rd.forward(request, response);
			}
			catch (InactiveAccountException e) 
			{	
				RequestDispatcher rd = request.getRequestDispatcher("InactiveAccount.jsp");
				rd.forward(request, response);
				
			} catch (InsufficientbalanceException e) {
				RequestDispatcher rd = request.getRequestDispatcher("InsufficientBalance.jsp");
				rd.forward(request, response);
			}
			
			
			
			
			
		}		//withdraw request recieved
		else if(action.equals("withdReq"))
		{
			
			//now we have to take the deposit amount
			Account acObj=(Account)request.getSession().getAttribute("accountDetails");
			double withdAmt = Double.parseDouble(request.getParameter("withdAmt"));
			//now pass the value to service 
			double latestBal = s.withdrawAmount(acObj,withdAmt);
			request.setAttribute("lbal", latestBal);
			request.setAttribute("acc", acObj);
			RequestDispatcher rd=request.getRequestDispatcher("WithdrawSuccess.jsp");
			rd.forward(request, response);
			
		}
		
		//withdraw request recieved
		else if(action.equals("depoReq"))
		{
			
			//now we have to take the deposit amount
			Account acObj=(Account)request.getSession().getAttribute("accountDetails");
			double depoAmt = Double.parseDouble(request.getParameter("depoAmt"));
			//now pass the value to service 
			double latestBal = s.depositAmount(acObj,depoAmt);
			request.setAttribute("lbal", latestBal);
			request.setAttribute("acc", acObj);
			RequestDispatcher rd=request.getRequestDispatcher("DepositSuccess.jsp");
			rd.forward(request, response);
			
		}
//		else if(action.equals("transfReq"))
//		{
//			
//			//now we have to take the transfer amount
//			long accountid=Long.parseLong(request.getParameter("accno"));
//			long targetid=Long.parseLong(request.getParameter("targaccno"));
//			double transfAmt = Double.parseDouble(request.getParameter("TransferAmt"));
//			//now pass the value to service 
//			
//			
//			
//			RequestDispatcher rd=request.getRequestDispatcher("DepositSuccess.jsp");
//			rd.forward(request, response);
//			
//		}
		
		
	}
}
		
	


