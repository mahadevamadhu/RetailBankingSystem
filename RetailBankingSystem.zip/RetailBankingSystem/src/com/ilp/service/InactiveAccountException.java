package com.ilp.service;

public class InactiveAccountException extends Exception {

}
