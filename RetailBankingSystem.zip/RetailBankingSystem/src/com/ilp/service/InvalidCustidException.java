package com.ilp.service;

public class InvalidCustidException extends Exception {

}
