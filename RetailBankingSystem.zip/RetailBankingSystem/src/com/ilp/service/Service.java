package com.ilp.service;

import java.sql.SQLException;
import java.util.ArrayList;

import com.ilp.bean.Account;
import com.ilp.bean.Customer;
import com.ilp.dao.DAO;

public class Service {

	DAO dao=new DAO();
		
	public String login(String user,String pass) 
	{
		String dep=null;
		dep=dao.LoginCheck(user, pass);
		return dep;
	}
	
	public boolean register(Customer c) throws CustomerInvalidException
	{
		boolean cust=false;
		
			cust = dao.addCustomer(c);
	 
		if(cust==false)
			throw new CustomerInvalidException();
		return cust;
	}
	
	public Customer fetchServicessnid(long SSNId) throws CustomerNotFoundException
	{
		Customer c=null;
		c=dao.fetchssnid(SSNId);
		if(c==null)
		{
			System.out.println(c);
			throw new CustomerNotFoundException();
		}
		return c;
		
	}
	public Customer fetchServicecustid(long SSNId) throws CustomerNotFoundException
	{
		Customer c=null;
		c=dao.fetchcustid(SSNId);
		if(c==null)
		{
			System.out.println(c);
			throw new CustomerNotFoundException();
		}
		return c;
		
	}
	
	public boolean UpdateCustom(Customer c)
	{
		boolean f=dao.Update(c);
		return f;
	}
	
	
	public boolean AddAccount(long custid,String accountType,double bal)
	{
		boolean f=dao.AddAccount(custid, accountType, bal);
		return f;
	}
	
	public boolean checkcust(long custid) throws CustomerAlreadyDeletedException 
	{
		int flag=0;
		boolean f=false;
		try {
			flag = dao.checkcustid(custid);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		if(flag==0)
		{
			throw new CustomerAlreadyDeletedException();
		}
		
		else if(flag>0)
			f=true;
		
		return f;
	}
	
	public boolean deletecust(long custid) 
	{
		String st=null;
		boolean flag=false;
		try {
			st= dao.deletecustomer(custid);
			flag=true;
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return flag;
	}
	
	public boolean deleteAccountBySsnid(long ssnid)
	{
		
			boolean flag=dao.deleteBySsnid(ssnid);
			return flag;
		
		
	}
	
	public boolean deleteAccountByCustid(long custid)
	{
		
			boolean flag=dao.deleteByCustid(custid);
			return flag;
		
			
	}
	
	public boolean checkCredentialCustid(long ssnid)throws InvalidCustidException
	{
		boolean f=dao.checkSsnid(ssnid);
		if(f==false)
			throw new InvalidCustidException();
		return f;
	}
	
	public boolean checkCredentialSSnid(long ssnid)throws InvalidSsnidException
	{
		boolean f=dao.checkSsnid(ssnid);
		if(f==false)
			throw new InvalidSsnidException();
		return f;
	}
	
	public ArrayList<Account> getAccountListBySsnid(long ssnid) throws AccountsNotFoundException
	{
		ArrayList<Account> alist=new ArrayList<Account>();
		alist=dao.getSsnidAccountList(ssnid);
		if(alist==null)
			throw new AccountsNotFoundException();
		return alist;
		
	}
	
	public ArrayList<Account> getAccountListByCustid(long custid)throws AccountsNotFoundException
	{
		ArrayList<Account> alist=new ArrayList<Account>();
		alist=dao.getCustidAccountList(custid);
		if(alist==null)
			throw new AccountsNotFoundException();
		return alist;
		
	}
	
	public Account getAccount(long accid)
	{
		Account acc=null;
		acc=dao.getAccountObj(accid);
		return acc;
	}

	/*public double withdrawAmount(Account acObj,Double withdAmt) {
		double latestBal = 0;
		latestBal = dao.getLatestBal(acObj,withdAmt);
		return latestBal;
	}*/	
	
	public double withdrawAmount(Account acObj,Double withdAmt) {
		double latestBal = 0;
		latestBal = dao.getLatestBal(acObj,withdAmt);
		return latestBal;
	}

	public double depositAmount(Account acObj, double depoAmt) {
		double latestBal = 0;
		latestBal = dao.getLatestBalAfterDeposit(acObj,depoAmt);
		return latestBal;
	}	
	public double getBalancesource(long accid)
	{
		double bsbalance=dao.getAccountBalance(accid);
		return bsbalance;
	}
	public double getBalancetarget(long accid)
	{
		double btbalance=dao.getAccountBalance(accid);
		return btbalance;
	}
	
	public void updatebalance(long sourceaccid,long targetaccid,double balance) throws InactiveAccountException, InsufficientbalanceException
	{
		
		boolean flag=false;
		Account a1=dao.getAccountObj(sourceaccid);
		Account a2=dao.getAccountObj(targetaccid);
		if((a1.getStatus().equalsIgnoreCase("Active")) && (a2.getStatus().equalsIgnoreCase("Active")))
		{
			if(a1.getBalance()>=balance)
			{
				flag=true;
				double sourceBalance = a1.getBalance()-balance;
				System.out.println("the sourceBalance "+sourceBalance);
				double targetBalance = a2.getBalance()+balance;
				System.out.println("the targetBalance "+targetBalance);
				dao.transfer(sourceaccid, sourceBalance);
				dao.transfer(targetaccid, targetBalance);
				
				
			}
			if(flag==false)
			{
				throw new InsufficientbalanceException();
			}
			
		}
		else
		{
			throw new InactiveAccountException();
		}
	
	}


	
}

